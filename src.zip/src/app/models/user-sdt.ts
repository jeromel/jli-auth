import { User } from '../../../projects/jli-auth/src/lib/models/user';

export class UserSDT {
    public User: User;
}