import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bons',
  templateUrl: './bons.component.html',
  styleUrls: ['./bons.component.css']
})
export class BonsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
